<?php
$quotes = array(
    "Lauf Forrest, lauf!", // Forrest Gump
    "Born to Run!", // Bruce Springsteen
    "Auch die längste Reise beginnt mit einem einzigen Schritt.", // Laotse
    "Das Glück ist mit Müdigkeit und Muskelkater billig erkauft.", // Leo Tolstoi
    "Wer die Welt bewegen will, sollte erst sich selbst bewegen." // Sokrates
);
function getQuotes(){
    global $quotes;

    $position = array_rand($quotes, 1);

    echo $quotes[$position];

}
?>