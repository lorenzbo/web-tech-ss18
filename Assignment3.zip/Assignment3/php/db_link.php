<?php
// database connection information
$db_host = "localhost";
$db_name = "BornToRun";
$db_user = "root";
$db_password = "";

$db_table = "Runs";

// establish database connection
$db_link = mysqli_connect($db_host, $db_user, $db_password) or die('Verbindung nicht möglich : ' . mysqli_connect_error());

// create database
$create_database_sql = "CREATE DATABASE IF NOT EXISTS " . $db_name;
mysqli_query($db_link, $create_database_sql) or die('Erstellen der Datenbank nicht möglich : ' . mysqli_error($db_link));
mysqli_select_db($db_link, $db_name) or die('Benutzung der Datenbank '. $db_name . ' nicht möglich: ' . mysqli_error($db_link)); 


function get_all_entries() {
    global $db_link;
    global $db_table;

    $sql = "SELECT * FROM ".$db_table;

    $result = mysqli_query($db_link, $sql);

    $allRuns = array();

    while($row = mysqli_fetch_array($result)){
        $run = array("date" => $row['Datum'], "duration" => $row['Dauer'], "distance" => $row['Distanz']);
        array_push($allRuns, $run);
    }
    $run2 = array("date" => "12.12.2012", "duration" => "117", "distance" => "17.4215");
    array_push($allRuns,$run2);
    return $allRuns;
}

function add_entry($input_date, $input_duration, $input_distance) {
    global $db_table;
    global $db_link;

    $sql ="INSERT INTO ".$db_table." (Datum, Dauer, Distanz) VALUES ('".$input_date."', ".$input_duration.", ".$input_distance.")";

    mysqli_query($db_link,  $sql);

}

function delete_entry($entry_id) {

}

function ensure_table_exists() {
    global $db_link, $db_table;

    $create_run_table = "CREATE TABLE IF NOT EXISTS `" . $db_table . "`
    (ID int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Datum DATE NOT NULL,
    Dauer INT NOT NULL,    
    Distanz FLOAT NOT NULL
    )";
  
    mysqli_query($db_link, $create_run_table) or die('Erstellen der Datenbanktabelle nicht möglich : ' . mysqli_error($db_link));
}

function reset_table() {

}

