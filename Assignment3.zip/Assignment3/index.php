<?php
include_once ("php/quotes.php");
include_once ("php/db_link.php");
ensure_table_exists();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Der Lauftracker</title>
    <meta charset="utf-8">

    <!-- Logo: Silk Icons http://www.famfamfam.com/lab/icons/silk/ -->
    <link rel="icon" href="logo.png" type="image/png">

    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <style>
        html {
            overflow-y: scroll;
        }
    </style>
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>



<body>
<div class="clearfix">
    <nav class="navbar navbar-expand-md navbar-dark bg-dark my-pagination-margin text-white">
        <a class="navbar-brand" href="#">Lauftracking</a>
           <ul class="navbar-nav mr-auto">
               <li class="nav-item active"><a class="nav-link" href="index.php">Start</a> </li>
               <li class="nav-item"><a class="nav-link" href="statistik.php">Statistik</a> </li>
           </ul>
    </nav>
</div>
<h4>
    <div class="p-3 mb-2 bg-secondary text-white text-center w-auto">
       <?php getQuotes(); ?>
    </div>
</h4>
<h3 class ="text-center font-weight-bold">Neuen Lauf eintragen</h3>

<form action="index.php" class="mr-4 ml-4 pl-4 pr-4" method="post">
  <div class="form-group">
    <label for = "date">Datum</label>
    <input type="date" class="form-control" name="date" placeholder = "tt.mm.jjjj">
  </div>
  <div class="form-group">
    <label for = "duration">Dauer</label>
    <input type="number" class="form-control" name="duration" placeholder = "Dauer">
    <small class="form-text text-muted">Einheit: Minuten</small>
  </div>
  <div class="form-group">
    <label for = "distance">Strecke</label>
    <input type="number" class="form-control" name="distance" placeholder = "Distanz">
    <small class="form-text text-muted">Einheit: Kilometer (km)</small>
  </div>
  <button type="submit" class="btn btn-primary">Eintragen</button>
</form>
<?php   
      if(isset($_POST["date"])&&isset($_POST["duration"])&&isset($_POST["distance"])){
         add_entry($_POST["date"], $_POST["duration"], $_POST["distance"]);
        }
?> 

<h3 class ="mt-4 mb-4 text-center font-weight-bold">Bisherige Läufe</h3>
    
<div class = "container">
    <section class = "row">
    <?php
             $allRuns = get_all_entries();
             $currentColumn = 0;

            foreach($allRuns as $run){
                $date = $run["date"];
                $duration = $run["duration"];
                $distance = $run["distance"];
                $paceinkmh = round($distance/($duration/60), 2);
                $paceinminkm = round($duration/$distance, 2);

               if($currentColumn == 0){
                echo '<div class="card bg-light col-md-5 mb-4">
                        <div class="card-body">
                            <label class="font-weight-bold">Datum</label>
                            <p class="card-text">'.$date .'</p>
                            <label class="font-weight-bold">Dauer</label>
                            <p class="card-text">'.$duration.' Minuten</p>
                            <label class="font-weight-bold">Distanz</label>
                            <p class="card-text">'.$distance.' km</p>
                            <label class="font-weight-bold">Geschwindigkeit - Pace</label>
                            <p class="card-text">'.$paceinkmh.'km/h - '.$paceinminkm.' Min/km</p>
                            <button type="submit" class="btn btn-primary">Löschen</button>
                        </div>
                    </div>';
                $currentColumn = 1;
               }else{
                   echo '<div class="card bg-light col-md-5 mb-4 offset-md-2">
                        <div class="card-body">
                            <label class="font-weight-bold">Datum</label>
                            <p class="card-text">'.$date .'</p>
                            <label class="font-weight-bold">Dauer</label>
                            <p class="card-text">'.$duration.' Minuten</p>
                            <label class="font-weight-bold">Distanz</label>
                            <p class="card-text">'.$distance.' km</p>
                            <label class="font-weight-bold">Geschwindigkeit - Pace</label>
                            <p class="card-text">'.$paceinkmh.'km/h - '.$paceinminkm.' Min/km</p>
                            <button type="submit" class="btn btn-primary">Löschen</button>
                        </div>
                    </div>';
                $currentColumn = 0;
               }
            }
             
        ?>
        


    </section>
</div>

</body>
</html>
